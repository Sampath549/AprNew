﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Uploads.Models;

namespace Uploads.Controllers
{
    public class UploadController : Controller
    {
        [HttpGet]
        public ActionResult UploadFile()
        {
            return View();
        }
        [HttpPost]
        public ActionResult UploadFile(FromFields _Fields)
        {
            try
            {
                if (_Fields.ImageFile.ContentLength > 0)
                {
                    string _FileExtention = Path.GetExtension(_Fields.ImageFile.FileName);
                    string _DateValue = DateTime.Now.Day.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString();
                    string _TimeValue = DateTime.Now.ToString("hh.mm.ss tt");
                    //string _DateTimeValue = DateTime.Now.ToString(@"dd/MM/yy hh:mm:ss tt", new CultureInfo("en-US"));
                    string _FileName = Path.GetFileName(_Fields.FileName) + " " + _DateValue + " " + _TimeValue + _FileExtention;
                    string _path = Path.Combine(Server.MapPath("~/UploadedFiles"), _FileName);
                    _Fields.ImageFile.SaveAs(_path);
                }
                ViewBag.Message = "File Uploaded Successfully..!";
                return View();
            }
            catch (Exception ex)
            {
                ViewBag.Message = "File upload failed" + " " + ex.Message;
                return View();
            }
        }
    }
}