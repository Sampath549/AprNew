﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Web;

namespace Uploads.Models
{
    public class FromFields
    {
        [DisplayName("File Name")]
        public string FileName { get; set; }
        [DisplayName("Upload File")]
        public string UploadPath { get; set; }
        public HttpPostedFileBase ImageFile { get; set; }
    }
}