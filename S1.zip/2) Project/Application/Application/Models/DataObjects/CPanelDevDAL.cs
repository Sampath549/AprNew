﻿using Application.Models.SharedEntities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;

namespace Application.Models.DataObjects
{
    public partial class CPanelDevDAL : DataAccessComponent
    {
        public bool CheckEmailMobile(string Email, string Mobile)
        {
            DataSet _Result = new DataSet();
            try
            {
                using (SqlConnection con = new SqlConnection(DB_ADOConnect))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter())
                    {
                        da.SelectCommand = new SqlCommand("SELECT Count(*) [Count] FROM [tbl_Users] WHERE Email = @Email OR Mobile = @Mobile", con);
                        da.SelectCommand.CommandType = CommandType.Text;
                        da.SelectCommand.Parameters.AddWithValue("@Email", Email);
                        da.SelectCommand.Parameters.AddWithValue("@Mobile", Mobile);

                        da.Fill(_Result);
                    }
                }

                if (Convert.ToInt32(_Result.Tables[0].Rows[0]["Count"]) == 0)
                    return false;
                else
                    return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public int InsertUsers(SE_Users _Data)
        {
            bool EmailMobileExists = CheckEmailMobile(_Data.Email, _Data.Mobile);
            if (!EmailMobileExists)
            {
                SqlConnection con = new SqlConnection(DB_ADOConnect);
                con.Open();
                try
                {
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "USP_Insert_Users";
                    cmd.Parameters.Add("@PersonalKey", SqlDbType.VarChar).Value = _Data.PersonalKey;
                    cmd.Parameters.Add("@FirstName", SqlDbType.VarChar).Value = _Data.FirstName;
                    cmd.Parameters.Add("@LastName", SqlDbType.VarChar).Value = _Data.LastName;
                    cmd.Parameters.Add("@Email", SqlDbType.VarChar).Value = _Data.Email;
                    cmd.Parameters.Add("@Mobile", SqlDbType.VarChar).Value = _Data.Mobile;
                    cmd.Parameters.Add("@RoleId", SqlDbType.VarChar).Value = _Data.RoleIdVal;
                    cmd.Parameters.Add("@Password", SqlDbType.VarChar).Value = _Data.Password;
                    cmd.Parameters.Add("@SaltKey", SqlDbType.VarChar).Value = _Data.SaltKey;

                    cmd.Connection = con;
                    cmd.ExecuteNonQuery();
                    return 1;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    con.Close();
                }
            }
            else
                return 101; // Email Or Mobile already Exists
        }
    }
}