﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.App_Start
{
    public class XssProtection : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var _Response = filterContext.HttpContext.Response;
            _Response.AddHeader("X-XSS-Protection", "1; mode=block");
        }
    }
}