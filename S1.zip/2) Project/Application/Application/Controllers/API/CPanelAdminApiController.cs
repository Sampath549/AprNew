﻿using Application.App_Start;
using Application.Filters;
using Application.Helper;
using Application.Models.DataObjects;
using Application.Models.SharedEntities;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Application.Controllers.API
{
    [RoutePrefix("api/CPanelAdmin")]
    public class CPanelAdminApiController : ApiController
    {
        SE_Users Users = new SE_Users();
        CPanelAdminDAL _ObjCPanelAdmin = new CPanelAdminDAL();
        CPanelDevDAL _ObjCPanelDev = new CPanelDevDAL();

        [HttpPost, Route("GetForms")]
        public Result<List<SE_Forms>> GetForms(ArrayList Array)
        {
            List<SE_Forms> _lst = new List<SE_Forms>();
            try
            {
                string _FormType = string.Empty;
                foreach (string val in Array)
                    _FormType = RSAPattern.Decrypt(val);

                _lst = _ObjCPanelAdmin.GetForms(_FormType);
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("CreateManualForms")]
        public Result CreateManualForms(ArrayList Array)
        {
            try
            {
                SE_Forms Forms = new SE_Forms();
                foreach (JObject val in Array)
                    Forms = val.ToObject<SE_Forms>();

                Forms.FormType = StringEncrypt.Encrypt(GlobalVariables.Shared.ManualFormType);
                Forms.Name = AES_Algorithm.EncryptString(RSAPattern.Decrypt(Forms.Name));
                Forms.Email = StringEncrypt.Encrypt(RSAPattern.Decrypt(Forms.Email));
                Forms.Mobile = StringEncrypt.Encrypt(RSAPattern.Decrypt(Forms.Mobile));
                Forms.Course = AES_Algorithm.EncryptString(RSAPattern.Decrypt(Forms.Course));
                Forms.Message = AES_Algorithm.EncryptString(RSAPattern.Decrypt(Forms.Message));

                int _Status = _ObjCPanelAdmin.InsertForms(Forms);

                if (_Status == 1)
                    return Result.Success(200, "Success", "Record Saved Successfully");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("CreateAllUsers")]
        public Result CreateAllUsers(ArrayList Array)
        {
            try
            {
                Users = new SE_Users();
                foreach (JObject val in Array)
                    Users = val.ToObject<SE_Users>();

                string ActualFName, ActualLName, ActualEmail, RandomPwd, SaltKey = string.Empty;
                ActualFName = RSAPattern.Decrypt(Users.FirstName);
                ActualLName = RSAPattern.Decrypt(Users.LastName);
                ActualEmail = RSAPattern.Decrypt(Users.Email);

                Users.PersonalKey = AES_Algorithm.EncryptString(Guid.NewGuid().ToString());
                Users.FirstName = AES_Algorithm.EncryptString(ActualFName);
                Users.LastName = AES_Algorithm.EncryptString(ActualLName);
                Users.Email = StringEncrypt.Encrypt(RSAPattern.Decrypt(Users.Email));
                Users.Mobile = StringEncrypt.Encrypt(RSAPattern.Decrypt(Users.Mobile));
                Users.RoleIdVal = RSAPattern.Decrypt(Users.RoleIdVal.ToString());
                SaltKey = PwdEncryption.GeneratePassword();
                Users.SaltKey = AES_Algorithm.EncryptString(SaltKey);
                RandomPwd = PwdEncryption.GeneratePassword();
                Users.Password = PwdEncryption.EncodePassword(RandomPwd, SaltKey);

                int _Status = _ObjCPanelDev.InsertUsers(Users);

                bool _SendMail = false;
                if (_Status == 1)
                {
                    if (Convert.ToInt32(Users.RoleIdVal) != GlobalVariables.Shared.StudentRoleId)
                    {
                        EmailHelper _EmailHelper = EmailHelper.Instance;
                        string _MessageBody = @"<div id='Template' width='100%' height=450'>
                                            <p>Dear <b>" + ActualFName + @" " + ActualLName + @"</b>..!!,</p>
                                            <p>Thank you for Joining EuroBharat. Here are the details.</p>
                                            <div style='margin-left:40px; color:initial;'>
                                            <table style='border:0'>
                                                <tr>
                                                    <td style='border:0'> Email:</td>
                                                    <td style='border:0'><strong>" + ActualEmail + @"</strong></td>
                                                </tr>
                                                <tr>
                                                    <td style='border:0'> Password:</td>
                                                    <td style='border:0'><strong>" + RandomPwd + @"</strong></td>
                                                </tr>
                                            </table>
                                        </div>
                                        <br/>
                                        <p style='margin-bottom: 0px'><strong> Important Note :</strong></p>
                                        <div style='margin-left:40px; margin-top: -15px; color:initial;'>
                                            <table style = 'border:0'>
                                                <tr>
                                                    <td style='border:0'>a. Please find the attached file for better understanding of EuroBharat.</td>
                                                </tr>
                                            </table>
                                        </div>
                                        <br/>
                                    </div>";
                        List<EmailAttachment> _Attachments = new List<EmailAttachment>();
                        _Attachments.Add(new EmailAttachment("Welcome.pdf", File.ReadAllBytes(System.Web.Hosting.HostingEnvironment.MapPath("~/Helper/Documents/Welcome.pdf"))));
                        string emailTo = string.Empty;
                        if (GlobalVariables.Shared.SendActualMails)
                            emailTo = ActualEmail;
                        else
                            emailTo = GlobalVariables.Shared.SendDefaultEmailTo;

                        if (!GlobalVariables.Shared.DontSendMail)
                            _SendMail = _EmailHelper.SendWithTemplate(emailTo, "", "Welcome Email", _EmailHelper.HTMLSanitize(_MessageBody), _Attachments);
                        else
                            _SendMail = true;
                    }
                    _SendMail = true;
                }

                if (_Status == 1 && _SendMail == false)
                    return Result.Failed(500, "Email Sending Failed", "User Created Successfully but Email Sending Failed");
                else if (_Status == 101)
                    return Result.Failed(500, "Duplicate Record", "Email / Mobile already exists");
                else
                    return Result.Success(200, "Success", "User Created Successfully");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("GetStudentDetails")]
        public Result<List<SE_Users>> GetStudentDetails(ArrayList Array)
        {
            List<SE_Users> _lst = new List<SE_Users>();
            try
            {
                _lst = _ObjCPanelAdmin.GetStudentDetails();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("EditStudentDetails")]
        public Result<SE_Users> EditStudentDetails(ArrayList Array)
        {
            List<SE_Users> _lst = new List<SE_Users>();
            string _id = string.Empty;
            try
            {
                foreach (string val in Array)
                    _id = RSAPattern.Decrypt(val);

                _lst = _ObjCPanelAdmin.EditStudentDetails(Convert.ToInt32(_id));
                return Result.Success(_lst[0], 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst[0], 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("UpdateStudentDetails")]
        public Result UpdateStudentDetails(ArrayList Array)
        {
            try
            {
                Users = new SE_Users();
                foreach (JObject val in Array)
                    Users = val.ToObject<SE_Users>();

                Users.UserId = Users.UserId;
                Users.FirstName = AES_Algorithm.EncryptString(RSAPattern.Decrypt(Users.FirstName));
                Users.LastName = AES_Algorithm.EncryptString(RSAPattern.Decrypt(Users.LastName));
                Users.IsActive = Users.IsActive;

                int _Status = _ObjCPanelAdmin.UpdateStudentDetails(Users);

                if (_Status == 1)
                    return Result.Success(200, "Success", "User Updated Successfully");
                else if (_Status == 101)
                    return Result.Failed(500, "UnAuthorized", "Not Authorized to Change the Details");
                else if (_Status == 100)
                    return Result.Failed(500, "No User", "No Record Exits");
                else
                    return Result.Failed(500, "Internal Server Error", "Something went Wrong");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("GetCourseCategory")]
        public Result<List<SE_RefValues>> GetCourseCategory(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanelAdmin.GetCourseCategory();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("InsertUpdateCourseCategory")]
        public Result InsertUpdateCourseCategory(ArrayList Array)
        {
            try
            {
                List<string> _lst = new List<string>();
                foreach (string val in Array)
                    _lst.Add(RSAPattern.Decrypt(val));

                int _Result = _ObjCPanelAdmin.InsertUpdateCourseCategory(_lst[0], _lst[1], _lst[2]);

                if (_Result == 1 && _lst[2].ToString() == "Save")
                    return Result.Success(200, "Success", "Record Saved Succesfully");
                if (_Result == 1 && _lst[2].ToString() == "Update")
                    return Result.Success(200, "Success", "Record Update Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Duplicate Code");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("DeleteCourseCategory")]
        public Result DeleteCourseCategory(ArrayList Array)
        {
            string _val = string.Empty;
            try
            {
                foreach (string val in Array)
                    _val = val.ToString();

                string Code = string.Empty;
                Code = RSAPattern.Decrypt(_val);

                int _Result = _ObjCPanelAdmin.DeleteCourseCategory(Code);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else if (_Result == 100)
                    return Result.Failed(500, "Error", "Refered With Other Records");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("CourseCategoryList")]
        public Result<List<SE_RefValues>> CourseCategoryList(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanelAdmin.CourseCategoryList();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("GetCourse")]
        public Result<List<SE_Course>> GetCourse(ArrayList Array)
        {
            List<SE_Course> _lst = new List<SE_Course>();
            try
            {
                _lst = _ObjCPanelAdmin.GetCourse();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("InsertUpdateCreateCourse")]
        public Result InsertUpdateCreateCourse(ArrayList Array)
        {
            try
            {
                List<string> _lst = new List<string>();
                foreach (string val in Array)
                    _lst.Add(RSAPattern.Decrypt(val));

                SE_Course _Course = new SE_Course();
                _Course.CategoryId = Convert.ToInt32(_lst[0]);
                _Course.Title = Convert.ToString(_lst[1]);
                _Course.Desc = Convert.ToString(_lst[2]);
                _Course.btnType = Convert.ToString(_lst[3]);

                int _Result = _ObjCPanelAdmin.InsertUpdateCreateCourse(_Course);

                if (_Result == 1 && _Course.btnType.ToString() == "Save")
                    return Result.Success(200, "Success", "Record Saved Succesfully");
                if (_Result == 1 && _Course.btnType.ToString() == "Update")
                    return Result.Success(200, "Success", "Record Update Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Duplicate Title");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("DeleteCourse")]
        public Result DeleteCourse(ArrayList Array)
        {
            string Title = string.Empty;
            try
            {
                foreach (string val in Array)
                    Title = RSAPattern.Decrypt(val.ToString());

                int _Result = _ObjCPanelAdmin.DeleteCourse(Title);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("GetCourseDetails")]
        public Result<List<SE_CourseDetails>> GetCourseDetails(ArrayList Array)
        {
            List<SE_CourseDetails> _lst = new List<SE_CourseDetails>();
            try
            {
                _lst = _ObjCPanelAdmin.GetCourseDetails();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("CourseList")]
        public Result<List<SE_RefValues>> CourseList(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanelAdmin.CourseList();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("InsertUpdateCourseDetails")]
        public Result InsertUpdateCourseDetails(ArrayList Array)
        {
            try
            {
                List<string> _lst = new List<string>();
                int i = 0;
                int Count = Array.Count;
                foreach (string val in Array)
                {
                    if (i == Array.Count - 3)
                        _lst.Add(val);
                    else
                    {
                        if (val != null)
                            _lst.Add(RSAPattern.Decrypt(val));
                        else
                            _lst.Add(null);
                    }
                    i++;
                }

                int _Result = _ObjCPanelAdmin.InsertUpdateCourseDetails(_lst[0], _lst[1], _lst[2], _lst[3], _lst[4], _lst[5], _lst[6], _lst[7], _lst[8]);

                if (_Result == 1 && _lst[8].ToString() == "Save")
                    return Result.Success(200, "Success", "Record Saved Succesfully");
                else if (_Result == 1 && _lst[8].ToString() == "Update")
                    return Result.Success(200, "Success", "Record Updated Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Already Exists");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("EditCourseDetails")]
        public Result<SE_CourseDetails> EditCourseDetails(ArrayList Array)
        {
            List<SE_CourseDetails> _lst = new List<SE_CourseDetails>();
            string _id = string.Empty;
            try
            {
                foreach (string val in Array)
                    _id = RSAPattern.Decrypt(val);

                _lst = _ObjCPanelAdmin.EditCourseDetails(Convert.ToInt32(_id));
                return Result.Success(_lst[0], 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst[0], 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("DeleteCourseDetails")]
        public Result DeleteCourseDetails(ArrayList Array)
        {
            string ID = string.Empty;
            try
            {
                foreach (string val in Array)
                    ID = RSAPattern.Decrypt(val.ToString());

                int _Result = _ObjCPanelAdmin.DeleteCourseDetails(ID);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("GetCourseContent")]
        public Result<List<SE_CourseContent>> GetCourseContent(ArrayList Array)
        {
            List<SE_CourseContent> _lst = new List<SE_CourseContent>();
            try
            {
                _lst = _ObjCPanelAdmin.GetCourseContent();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("InsertUpdateCourseContent")]
        public Result InsertUpdateCourseContent(ArrayList Array)
        {
            try
            {
                List<string> _lst = new List<string>();
                int i = 0;
                int Count = Array.Count;
                foreach (string val in Array)
                {
                    if (i == Array.Count - 2)
                        _lst.Add(val);
                    else
                    {
                        if (val != null)
                            _lst.Add(RSAPattern.Decrypt(val));
                        else
                            _lst.Add(null);
                    }
                    i++;
                }

                int _Result = _ObjCPanelAdmin.InsertUpdateCourseContent(_lst[0], _lst[1], _lst[2], _lst[3]);

                if (_Result == 1 && _lst[3].ToString() == "Save")
                    return Result.Success(200, "Success", "Record Saved Succesfully");
                if (_Result == 1 && _lst[3].ToString() == "Update")
                    return Result.Success(200, "Success", "Record Update Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Duplicate Code");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("DeleteCourseContent")]
        public Result DeleteCourseContent(ArrayList Array)
        {
            string _val = string.Empty;
            try
            {
                foreach (string val in Array)
                    _val = val.ToString();

                string ID = string.Empty;
                ID = RSAPattern.Decrypt(_val);

                int _Result = _ObjCPanelAdmin.DeleteCourseContent(ID);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else if (_Result == 100)
                    return Result.Failed(500, "Error", "Refered With Other Records");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("StudentsList")]
        public Result<List<SE_RefValues>> StudentsList(ArrayList Array)
        {
            List<SE_RefValues> _lst = new List<SE_RefValues>();
            try
            {
                _lst = _ObjCPanelAdmin.StudentsList();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("CreateBatch")]
        public Result CreateBatch(ArrayList Array)
        {
            try
            {
                List<string> _lst = new List<string>();
                int i = 0;
                foreach (string val in Array)
                {
                    if (i == Array.Count - 1)
                        _lst.Add(val);
                    else
                        _lst.Add(RSAPattern.Decrypt(val));
                    i++;
                }

                SE_Batches _Batch = new SE_Batches();
                _Batch.CourseId = Convert.ToInt32(_lst[0]);
                _Batch.StaffName = Convert.ToString(_lst[1]);
                _Batch.BatchStartDate = Convert.ToDateTime(_lst[2]);
                _Batch.BatchTime = Convert.ToString(_lst[3]);
                _Batch.SingleValStudents = Convert.ToString(_lst[4]);

                int _Result = _ObjCPanelAdmin.CreateBatch(_Batch);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Saved Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Please Submit the Data Again");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("GetBatchDetails")]
        public Result<List<SE_Batches>> GetBatchDetails(ArrayList Array)
        {
            List<SE_Batches> _lst = new List<SE_Batches>();
            try
            {
                _lst = _ObjCPanelAdmin.GetBatchDetails();
                return Result.Success(_lst, 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst, 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("EditBatchDetails")]
        public Result<SE_Batches> EditBatchDetails(ArrayList Array)
        {
            List<SE_Batches> _lst = new List<SE_Batches>();
            string _id = string.Empty;
            try
            {
                foreach (string val in Array)
                    _id = RSAPattern.Decrypt(val);

                _lst = _ObjCPanelAdmin.EditBatchDetails(Convert.ToInt32(_id));
                return Result.Success(_lst[0], 200, "Success", "Success");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(_lst[0], 500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("UpdateBatchDetails")]
        public Result UpdateBatchDetails(ArrayList Array)
        {
            try
            {
                List<string> _lst = new List<string>();
                int i = 0;
                foreach (string val in Array)
                {
                    if (i >= Array.Count - 2)
                        _lst.Add(val);
                    else
                        _lst.Add(RSAPattern.Decrypt(val));
                    i++;
                }

                SE_Batches _Batch = new SE_Batches();
                _Batch.StaffName = Convert.ToString(_lst[0]);
                _Batch.BatchStartDate = Convert.ToDateTime(_lst[1]);
                _Batch.BatchTime = Convert.ToString(_lst[2]);
                _Batch.BatchId = Convert.ToString(_lst[3]);
                _Batch.SingleValStudents = Convert.ToString(_lst[4]);

                int _Result = _ObjCPanelAdmin.UpdateBatchDetails(_Batch);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Updated Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Please Submit the Data Again");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }

        [HttpPost, Route("DeleteBatch")]
        public Result DeleteBatch(ArrayList Array)
        {
            string _val = string.Empty;
            try
            {
                foreach (string val in Array)
                    _val = val.ToString();

                string ID = string.Empty;
                ID = RSAPattern.Decrypt(_val);

                int _Result = _ObjCPanelAdmin.DeleteBatch(ID);

                if (_Result == 1)
                    return Result.Success(200, "Success", "Record Deleted Succesfully");
                else if (_Result == 99)
                    return Result.Failed(500, "Error", "Record Does Not Exist");
                else if (_Result == 100)
                    return Result.Failed(500, "Error", "Refered With Other Records");
                else
                    return Result.Failed(500, "Error", "Internal Server Error");
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Result.Failed(500, GlobalVariables.Shared.InternalErrorMsg);
            }
        }
    }
}
