﻿using Application.App_Start;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    public class UserController : Controller
    {
        [ContentSecurityPolicy]
        public ActionResult Home()
        {
            return View();
        }

        [ContentSecurityPolicy]
        public ActionResult About()
        {
            return View();
        }

        [ContentSecurityPolicy]
        public ActionResult Courses()
        {
            return View();
        }

        [ContentSecurityPolicy]
        public ActionResult CourseDetails()
        {
            return View();
        }

        [ContentSecurityPolicy]
        public ActionResult Blogs()
        {
            return View();
        }

        [ContentSecurityPolicy]
        public ActionResult BlogDetails()
        {
            return View();
        }

        [ContentSecurityPolicy]
        public ActionResult FAQ()
        {
            return View();
        }

        [ContentSecurityPolicy]
        public ActionResult Contact()
        {
            return View();
        }
    }
}