﻿using Application.App_Start;
using Application.Filters;
using Application.Helper;
using Application.Models.SharedEntities;
using Microsoft.Security.Application;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace Application.Controllers
{
    [MVCSessionFilter, MVCDevAuthorization]
    public class CPanelDevController : Controller
    {
        public ActionResult Dashboard()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateAllUsers()
        {
            try
            {
                ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
                ViewBag.Roles_dll = Reusable.RolesList(); // All Roles
                return View();
            }
            catch (Exception ex)
            {
                return RedirectToAction(StatusCode.ErrorPage(ex, 500), "Error");
            }
        }
        [HttpPost, CSRF_AntiForgeryToken]
        public JsonResult CreateAllUsers(SE_Users _User)
        {
            SE_Users Users = new SE_Users();
            try
            {
                //Server-Side Validations
                if (_User.FirstName == null || Sanitizer.GetSafeHtmlFragment(_User.FirstName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.FirstName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.FirstName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "First Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.LastName == null || Sanitizer.GetSafeHtmlFragment(_User.LastName) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.LastName), @"^[a-zA-Z\s]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length > 35 || Sanitizer.GetSafeHtmlFragment(_User.LastName).Length < 3)
                    return Json(new Result(false, 500, "Validation Error", "Last Name should not be Empty and must contain only Alphabets with Minimum of 3 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Email == null || Sanitizer.GetSafeHtmlFragment(_User.Email) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Email), @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Email).Length > 75)
                    return Json(new Result(false, 500, "Validation Error", "Email should not be Empty and must be a Valid format with max of 75 characters"), JsonRequestBehavior.AllowGet);
                if (_User.Mobile == null || Sanitizer.GetSafeHtmlFragment(_User.Mobile) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.Mobile), @"^[0-9]+$") == false || Sanitizer.GetSafeHtmlFragment(_User.Mobile).Length != 10)
                    return Json(new Result(false, 500, "Validation Error", "Mobile should not be Empty and must contain only Numbers with 10 digits"), JsonRequestBehavior.AllowGet);
                if (Sanitizer.GetSafeHtmlFragment(_User.RoleId.ToString()) == "" || Regex.IsMatch(Sanitizer.GetSafeHtmlFragment(_User.RoleId.ToString()), @"^[0-9]+$") == false)
                    return Json(new Result(false, 500, "Validation Error", "Please Select Role"), JsonRequestBehavior.AllowGet);

                //RSA Encryption
                Users = new SE_Users();
                Users.FirstName = RSAPattern.Encrypt(_User.FirstName);
                Users.LastName = RSAPattern.Encrypt(_User.LastName);
                Users.Email = RSAPattern.Encrypt(_User.Email);
                Users.Mobile = RSAPattern.Encrypt(_User.Mobile);
                Users.RoleIdVal = RSAPattern.Encrypt(_User.RoleId.ToString());

                //API Call
                ArrayList _Array = new ArrayList();
                _Array.Add(Users);
                string response = ApiHelper.PostData_Json("api/CPanelDev/CreateAllUsers?Users=", _Array);
                Result _Result = JsonConvert.DeserializeObject<Result>(response);
                if (_Result.Status)
                    SessionHandler.SessionStudentsList = null;

                return Json(_Result, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Reusable.ErrorMsgText(ex);
                return Json(new Result(false, 500, GlobalVariables.Shared.InternalErrorMsg, null), JsonRequestBehavior.AllowGet);
            }
        }
        public ActionResult AllUserDetails()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateRole()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateMenus()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateSubMenus()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateAssignedMenus()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateCountries()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult CreateStates()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
        public ActionResult ViewErrorLog()
        {
            ViewBag.Menus = Reusable.BindMenus();   // Bind Menus
            return View();
        }
    }
}