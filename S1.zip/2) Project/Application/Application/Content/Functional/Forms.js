﻿$(document).ready(function () {
    $('#btnAddManualForms').on("click", function (event) {
        event.preventDefault();
        $(".loadingImg").show();
        var url = '/CPanelAdmin/AddManualForms';
        $.get(url, function (data) {
            $('#CreateFormData').html(data);
            $('.notification-sidebar').toggleClass('open');
            $(".loadingImg").hide();
        });
    });

    GetTable();

});


function GetTable() {
    Table = $('.GetFormDetails').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "sAjaxSource": '/CPanelAdmin/GetForms?_FormType=ManualForm',
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",
        "columns": [
            { "visible": false, "sWidth": "10%", "sClass": "FormId", "render": function (data, type, row) { return row[0]; } },
            { "sWidth": "20%", "sClass": "FormType DisapbelDTColumn", "render": function (data, type, row) { return (row[1]); } },
            { "sWidth": "40%", "sClass": "Name", "render": function (data, type, row) { return (row[2]); } },
            { "sClass": "Email DisapbelDTColumn", "render": function (data, type, row) { return (row[3]); } },
            { "sClass": "Mobile DisapbelDTColumn", "render": function (data, type, row) { return (row[4]); } },
            { "sClass": "Course", "render": function (data, type, row) { return (row[5]); } },
            { "sWidth": "20%", "sClass": "Message DisapbelDTColumn", "render": function (data, type, row) { return (row[6]); } },
            {
                "sWidth": "10%",
                "bSortable": false,
                "sClass": "textAlignCenter",
                "render": function (data, type, row) {
                    return '<center><a href="javascript:void(0);" onclick=ViewData(this); class="viewForms" title="View" return false;> <i class="fa fa-eye"></i></a></center>';
                }, "targets": 0,
            }
        ],
    });
}