﻿$(document).ready(function () {

    $('#BDBatchCode').attr('disabled', true);
    $('#CourseId').attr('disabled', true);

    // Date Selection not more than current Date
    var today = new Date()
    day = today.getDate(), month = today.getMonth() + 1, year = today.getFullYear();
    if (day < 10)
        day = '0' + day
    if (month < 10)
        month = '0' + month
    today = year + '-' + month + '-' + day;
    $("#BDSDate").attr("min", today);

    // Display or Not to display depending on the count
    var tblRowCount = $('#tblEditStudents >tbody >tr').length;
    if (tblRowCount == 0)
        $('.StudentstblEditDiv').hide();
    else
        $('.StudentstblEditDiv').show();

    // Add dynamic rows in table
    $("#btnEditAddTable").click(function (event) {
        event.preventDefault();
        var _Name = $("#EditBStu").val();
        if (_Name != "") {
            $('.StudentstblEditDiv').show();
            var markup = "<tr>"
            markup += "<td><div class='custom-control custom-checkbox m-0'><input type='checkbox' name='Editrecord' class='custom-control-input' id=Edit'" + _Name + "'><label class='custom-control-label' for=Edit'" + _Name + "'></label></div></td>";
            markup += "<td style='text-align:left !important;' class='ActualTDVal'>" + _Name + "</td>";
            markup += "</tr>";
            $("#tblEditStudents tbody").append(markup);
            $('#EditBStu').val('');
        }
        else
            toastr.error('Add Students is Empty', opts);
    });

    // Find and remove selected table rows
    $("#btnEditRemoveTable").click(function (event) {
        event.preventDefault();
        $("#tblEditStudents tbody").find('input[name="Editrecord"]').each(function () {
            if ($(this).is(":checked")) {
                $(this).parents("tr").remove();
            }
        });

        var tblRowCountDelete = $('#tblEditStudents >tbody >tr').length;
        if (tblRowCountDelete == 0)
            $('.StudentstblEditDiv').hide();
        else
            $('.StudentstblEditDiv').show();
    });

    $("#EditBStu").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: '/CPanelAdmin/AutoCompleteStudents/',
                data: "{ 'prefix': '" + request.term + "'}",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    response($.map(data, function (item) {
                        return item;
                    }))
                },
                error: function (response) {
                    toastr.error(response.responseText, '', opts);
                },
                failure: function (response) {
                    toastr.error(response.responseText, '', opts);
                }
            });
        }
    });

    $("#BatchDetailsForm").validate({
        rules: {
            'BDSName': {
                required: true,
                maxlength: 50,
                minlength: 2,
                lettersonly: true
            },
            'BDSDate': {
                required: true
            },
            'BDTime': {
                required: true
            }
        },
        messages: {
            'BDSName': {
                required: 'Enter Staff Name'
            },
            'BDSDate': {
                required: 'Enter Batch Date'
            },
            'BDTime': {
                required: 'Enter Batch Time'
            }
        },
        submitHandler: function () {
            setTimeout(function () {
                $(".loadingImg").show();
                var arrData = [];
                $("#tblEditStudents tr").each(function () {
                    var currentRow = $(this);
                    var colValue = currentRow.find("td:eq(1)").text();
                    if (colValue != "")
                        arrData.push(colValue)
                });

                var _postData = {
                    BatchId: $('#PKID').val(),
                    StaffName: $('#BDSName').val(),
                    BatchStartDate: $('#BDSDate').val(),
                    BatchTime: $('#BDTime').val(),
                    SingleValStudents: JSON.stringify(arrData)
                };

                console.log(_postData);

                $.ajax({
                    type: "POST",
                    url: "/CPanelAdmin/UpdateBatchDetails",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                        if (!response.Status)
                            toastr.error(response.Message, response.Caption, opts);
                        else {
                            swal({
                                title: "Success!",
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    ClearFields();
                                    $('.notification-sidebar').removeClass('open');
                                    location.reload();
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        toastr.error(xhr.responseText, '', opts);
                    }
                });
            }, 0);
        }
    });

    $('.notification-sidebar-close').on('click', function () {
        $('.notification-sidebar').removeClass('open');
    });
});