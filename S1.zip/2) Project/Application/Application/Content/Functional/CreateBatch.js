﻿jQuery.validator.addMethod("selectNone", function (value, element) {
    return this.optional(element) || element.selectedIndex != 0;
}, "Please select an option.");

jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

var opts = {
    "closeButton": true,
    "debug": false,
    "positionClass": "toast-top-full-width",
    "onclick": null,
    "showDuration": null,
    "hideDuration": null,
    "timeOut": null,
    "extendedTimeOut": null,
    "showEasing": "swing",
    "hideEasing": "linear",
    "showMethod": "fadeIn",
    "hideMethod": "fadeOut"
};

$(document).ready(function () {

    // Date Selection not more than current Date
    var today = new Date()
    day = today.getDate(), month = today.getMonth() + 1, year = today.getFullYear();
    if (day < 10)
        day = '0' + day
    if (month < 10)
        month = '0' + month
    today = year + '-' + month + '-' + day;
    $("#BSDate").attr("min", today);

    // AutoComplete
    $("#BStu").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: '/CPanelAdmin/AutoCompleteStudents/',
                data: "{ 'prefix': '" + request.term + "'}",
                dataType: "json",
                type: "POST",
                contentType: "application/json; charset=utf-8",
                success: function (data) {
                    response($.map(data, function (item) {
                        return item;
                    }))
                },
                error: function (response) {
                    toastr.error(response.responseText, '', opts);
                },
                failure: function (response) {
                    toastr.error(response.responseText, '', opts);
                }
            });
        }
    });

    // Display or Not to display depending on the count
    var tblRowCount = $('#tblStudents >tbody >tr').length;
    if (tblRowCount == 0)
        $('.StudentstblDiv').hide();
    else
        $('.StudentstblDiv').show();

    // Add dynamic rows in table
    $("#btnAddTable").click(function (event) {
        event.preventDefault();
        var _Name = $("#BStu").val();
        if (_Name != "") {
            $('.StudentstblDiv').show();
            var markup = "<tr>"
            markup += "<td><div class='custom-control custom-checkbox m-0'><input type='checkbox' name='record' class='custom-control-input' id='" + _Name + "'><label class='custom-control-label' for='" + _Name + "'></label></div></td>";
            markup += "<td style='text-align:left !important;' class='ActualTDVal'>" + _Name + "</td>";
            markup += "</tr>";
            $("#tblStudents tbody").append(markup);
            $('#BStu').val('');
        }
        else
            toastr.error('Add Students is Empty', opts);
    });

    // Find and remove selected table rows
    $("#btnRemoveTable").click(function (event) {
        event.preventDefault();
        $("#tblStudents tbody").find('input[name="record"]').each(function () {
            if ($(this).is(":checked")) {
                $(this).parents("tr").remove();
            }
        });

        var tblRowCountDelete = $('#tblStudents >tbody >tr').length;
        if (tblRowCountDelete == 0)
            $('.StudentstblDiv').hide();
        else
            $('.StudentstblDiv').show();
    });

    // Validations & ajax Calls
    $("#CreateBatch").validate({
        rules: {
            'CourseID': {
                selectNone: true
            },
            'BSName': {
                required: true,
                maxlength: 50,
                minlength: 2,
                lettersonly: true
            },
            'BSDate': {
                required: true
            },
            'BTime': {
                required: true
            }
        },
        messages: {
            'CourseID': {
                selectNone: 'Please Select Course'
            },
            'BSName': {
                required: 'Enter Staff Name'
            },
            'BSDate': {
                required: 'Enter Batch Date'
            },
            'BTime': {
                required: 'Enter Batch Time'
            }
        },
        submitHandler: function () {
            setTimeout(function () {
                $(".loadingImg").show();
                var arrData = [];
                $("#tblStudents tr").each(function () {
                    var currentRow = $(this);
                    var colValue = currentRow.find("td:eq(1)").text();
                    if (colValue != "")
                        arrData.push(colValue)
                });

                var _postData = {
                    CourseId: $('#CourseID').val(),
                    StaffName: $('#BSName').val(),
                    BatchStartDate: $('#BSDate').val(),
                    BatchTime: $('#BTime').val(),
                    SingleValStudents: JSON.stringify(arrData)
                };

                $.ajax({
                    type: "POST",
                    url: "/CPanelAdmin/CreateBatch",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                        if (!response.Status)
                            toastr.error(response.Message, response.Caption, opts);
                        else {
                            swal({
                                title: "Success!",
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    ClearFields();
                                    GetTable();
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        toastr.error(xhr.responseText, '', opts);
                    }
                });
            }, 0);
        }
    });

    $("#btnCancel").click(function () {
        ClearFields();
    });

    // Edit Record
    $('.GetBatchDetails').on("click", ".editBatchDetails", function (event) {
        event.preventDefault();
        $(".loadingImg").show();
        //$('#MainBody').css("background-color","blue");
        var url = $(this).attr("href");
        $.get(url, function (data) {
            $('#CreateBDData').html(data);
            $('.notification-sidebar').toggleClass('open');
            $(".loadingImg").hide();
        });
    });

    GetTable();
});

function GetTable(event) {
    Table = $('.GetBatchDetails').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "sAjaxSource": '/CPanelAdmin/GetBatchDetails',
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",
        "columns": [
            { "visible": false, "sWidth": "10%", "sClass": "TextCenter BatchId", "render": function (data, type, row) { return row[0]; } },
            { "sWidth": "12%", "sClass": "textAlignCenter Batch", "render": function (data, type, row) { return (row[1]); } },
            { "sClass": "Course", "render": function (data, type, row) { return (row[3]); } },
            { "sWidth": "12%", "sClass": "textAlignCenter DateTime", "render": function (data, type, row) { return (row[4]); } },
            { "sWidth": "12%", "sClass": "textAlignCenter Students", "render": function (data, type, row) { return (row[5]); } },
            {
                "sWidth": "6%",
                "bSortable": false,
                "sClass": "textAlignCenter",
                "render": function (data, type, row) {
                    return '<center><a href="/CPanelAdmin/EditBatchDetails?id=' + row[0] + '" class="editBatchDetails notification-sidebar-toggle" title="Edit" return false;> <i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" title="Delete"  onclick=DeleteData("' + row[0] + '"); return false;> <i class="fa fa-trash-o"></i></a></center>';
                }, "targets": 0,
            }
        ],
    });
}

function DeleteData(Id) {
    swal({
        title: "Are you sure?",
        text: "This will delete the Record",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes, Delete it!",
        closeOnConfirm: false
    },
        function (isConfirm) {
            if (isConfirm) {
                $(".loadingImg").show();
                $.ajax({
                    url: '/CPanelAdmin/DeleteBatch',
                    type: 'POST',
                    data: JSON.stringify({ "ID": Id }),
                    contentType: 'application/json; charset=utf-8;',
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (result) {
                        if (result.Status) {
                            swal("Deleted!", result.Message, "success");
                            GetTable();
                        }
                        else
                            swal("Cancelled!", result.Message, "error");

                        $(".loadingImg").hide();
                    }
                });
            }
        }
    );
}

function ClearFields() {
    $("#CourseID").val('0');
    $("#BSName").val('');
    $("#BSDate").val('');
    $('#BTime').val('');
    $("table tbody").find('input[name="record"]').each(function () {
        $(this).parents("tr").remove();
    });
    $('.StudentstblDiv').hide();
}

