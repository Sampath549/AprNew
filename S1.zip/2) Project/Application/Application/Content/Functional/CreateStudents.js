﻿jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

jQuery.validator.addMethod("numbersonly", function (value, element) {
    return this.optional(element) || /^[0-9]+$/i.test(value);
}, "Enter Only Numbers");

jQuery.validator.addMethod("selectNone", function (value, element) {
    return this.optional(element) || element.selectedIndex != 0;
}, "Please select an option.");

jQuery.validator.addMethod("customEmail", function (value, element) {
    return /^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/.test(value);
}, "Enter a Valid Email");

var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };

$(document).ready(function () {
    GetTable();

    $('.GetStudentDetails').on("click", ".editStudentDetails", function (event) {
        event.preventDefault();
        $(".loadingImg").show();
        var url = $(this).attr("href");
        $.get(url, function (data) {
            $('#CreateSDData').html(data);
            $('.notification-sidebar').toggleClass('open');
            $(".loadingImg").hide();
        });
    });

    $("#CreateStudentForm").validate({
        rules: {
            'CUFName': {
                required: true,
                minlength: 2,
                lettersonly: true
            },
            'CULName': {
                required: true,
                lettersonly: true
            },
            'CUEmail': {
                required: true,
                customEmail: true
            },
            'CUMobile': {
                required: true,
                numbersonly: true,
                maxlength: 10
            }
        },
        messages: {
            'CUFName': {
                required: 'Enter First Name',
                minlength: 'Must enter Minimum of 2 characters'
            },
            'CULName': {
                required: 'Enter Last Name'
            },
            'CUEmail': {
                required: 'Enter Email'
            },
            'CUMobile': {
                required: 'Enter Mobile Number'
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();
            setTimeout(function () {
                var _postData = {
                    FirstName: $('#CUFName').val(),
                    LastName: $('#CULName').val(),
                    Email: $('#CUEmail').val(),
                    Mobile: $('#CUMobile').val()
                };

                $.ajax({
                    type: "POST",
                    url: "/CPanelAdmin/CreateStudents",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        if (!response.Status)
                            toastr.error(response.Message, response.Caption, opts);
                        else {
                            swal({
                                title: "Success!",
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    ClearFields();
                                    GetTable();
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        toastr.error(xhr.responseText, '', opts);
                    }
                });
            }, 0);
        }
    });
    $("#btnCancel").click(function () {
        ClearFields();
    });
});


function GetTable(event) {
    Table = $('.GetStudentDetails').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "sAjaxSource": '/CPanelAdmin/GetStudentDetails',
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",
        "columns": [
            { "visible": false, "sWidth": "10%", "sClass": "TextCenter UserId", "render": function (data, type, row) { return row[0]; } },
            { "sWidth": "20%", "sClass": "FullName", "render": function (data, type, row) { return (row[1]); } },
            { "sWidth": "20%", "sClass": "Email", "render": function (data, type, row) { return (row[4]); } },
            { "sWidth": "10%", "sClass": "textAlignCenter Batches", "render": function (data, type, row) { return (row[8]); } },
            { "sWidth": "7%", "sClass": "textAlignCenter Mobile", "render": function (data, type, row) { return (row[5]); } },
            { "sWidth": "7%", "sClass": "textAlignCenter Role", "render": function (data, type, row) { return (row[6]); } },
            { "sWidth": "8%", "sClass": "textAlignCenter IsActive", "render": function (data, type, row) { return (row[7]); } },
            {
                "sWidth": "5%",
                "bSortable": false,
                "sClass": "TextCenter",
                "render": function (data, type, row) {
                    return '<center><a href="/CPanelAdmin/EditStudentDetails?id=' + row[0] + '"  class="editStudentDetails notification-sidebar-toggle" title="Edit" return false;> <i class="fa fa-edit"></i></a>&nbsp;&nbsp;</center>';
                }, "targets": 0,
            }
        ],
    });
}

function ClearFields() {
    $("#CUFName").val('');
    $("#CULName").val('');
    $('#CUEmail').val('');
    $('#CUMobile').val('');
}