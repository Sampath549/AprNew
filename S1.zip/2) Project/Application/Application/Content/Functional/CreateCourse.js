﻿jQuery.validator.addMethod("selectNone", function (value, element) {
    return this.optional(element) || element.selectedIndex != 0;
}, "Please select an option.");

var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };

$(document).ready(function () {

    GetTable();

    $('#btnSaveDetails').val("Save");

    $("#CreateCourse").validate({
        rules: {
            'CCID': {
                selectNone: true
            },
            'CTitle': {
                required: true,
                minlength: 2,
                maxlength: 100,
            },
            'CDesc': {
                required: true,
                minlength: 2
            }
        },
        messages: {
            'CCID': {
                selectNone: 'Please Select Category'
            },
            'CTitle': {
                required: 'Enter Title',
                minlength: 'Must enter Minimum of 2 characters',
                maxlength: 'Must enter Maximum of 100 characters'
            },
            'CDesc': {
                required: 'Enter Description',
                minlength: 'Must enter Minimum of 2 characters'
            }
        },
        submitHandler: function () {
            setTimeout(function () {
                $(".loadingImg").show();
                var _postData = {
                    CategoryId: $('#CCID').val(),
                    Title: $('#CTitle').val(),
                    Desc: $('#CDesc').val(),
                    btnType: $('#btnSaveDetails').val()
                };

                $.ajax({
                    type: "POST",
                    url: "/CPanelAdmin/CreateCourse",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        if (!response.Status)
                            toastr.error(response.Message, response.Caption, opts);
                        else {
                            swal({
                                title: "Success!",
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    ClearFields();
                                    GetTable();
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        toastr.error(xhr.responseText, '', opts);
                    }
                });
            }, 0);
        }
    });
    $("#btnCancel").click(function () {
        ClearFields();
    });
});

function GetTable() {
    Table = $('.GetCourse').DataTable({
        "processing": true,
        "serverSide": false,
        "paging": true,
        "ordering": true,
        "info": true,
        "searching": true,
        "bFilter": false,
        "scrollX": "100%",
        "scrollY": ($(window).height() - 500),
        "sScrollXInner": "100%",
        "bScrollCollapse": true,
        "sAjaxSource": '/CPanelAdmin/GetCourse',
        "bDestroy": true,
        "bLengthChange": true,
        "bPaginate": true,
        "sEmptyTable": "Loading data from server",
        "columns": [
            { "visible": false, "sWidth": "10%", "sClass": "CourseId", "render": function (data, type, row) { return row[0]; } },
            { "sWidth": "20%", "sClass": "CategoryId DisapbelDTColumn", "render": function (data, type, row) { return (row[1]); } },
            { "sWidth": "20%", "sClass": "Category", "render": function (data, type, row) { return (row[2]); } },
            { "sClass": "Title", "render": function (data, type, row) { return (row[3]); } },
            { "sWidth": "20%", "sClass": "Desc DisapbelDTColumn", "render": function (data, type, row) { return (row[4]); } },
            {
                "sWidth": "10%",
                "bSortable": false,
                "sClass": "textAlignCenter",
                "render": function (data, type, row) {
                    return '<center><a href="javascript:void(0);" onclick=EditData(this); class="editCourseCategory" title="Edit" return false;> <i class="fa fa-edit"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="javascript:void(0);" title="Delete"  onclick=DeleteData("' + row[3] + '"); return false;> <i class="fa fa-trash-o"></i></a></center>';
                }, "targets": 0,
            }
        ],
    });
}

function EditData(row) {
    window.scrollTo(0, 0);
    var CategoryId = $(row).closest('tr').find('.CategoryId').html();
    $('#CCID').val(CategoryId);

    var Title = $(row).closest('tr').find('.Title').html();
    $('#CTitle').val(Title);

    var Desc = $(row).closest('tr').find('.Desc').html();
    $('#CDesc').val(Desc);

    $('#CTitle').attr('disabled', true);
    $('#CCID').attr('disabled', true);
    $('#btnSaveDetails').val("Update");
}

function DeleteData(code) {
    swal({
        title: "Are you sure?",
        text: "This will delete the Record",
        type: "warning",
        showCancelButton: true,
        confirmButtonClass: "btn-danger",
        confirmButtonText: "Yes, Delete it!",
        closeOnConfirm: false
    },
        function (isConfirm) {
            if (isConfirm) {
                $(".loadingImg").show();
                $.ajax({
                    url: '/CPanelAdmin/DeleteCourse',
                    type: 'POST',
                    data: JSON.stringify({ "Title": code }),
                    contentType: 'application/json; charset=utf-8;',
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (result) {
                        if (result.Status) {
                            swal("Deleted!", result.Message, "success");
                            GetTable();
                        }
                        else
                            swal("Cancelled!", result.Message, "error");
                        $(".loadingImg").hide();
                    }
                });
            }
        }
    );
}

function ClearFields() {
    $("#CTitle").val('');
    $("#CDesc").val('');
    $("#CCID").val('0');
    $('#CTitle').attr('disabled', false);
    $('#CCID').attr('disabled', false);
    $('#btnSaveDetails').val("Save");
}