﻿jQuery.validator.addMethod("selectNone", function (value, element) {
    return this.optional(element) || element.selectedIndex != 0;
}, "Please select an option.");

jQuery.validator.addMethod("numbersonly", function (value, element) {
    return this.optional(element) || /^[0-9]+$/i.test(value);
}, "Enter Only Numbers");

jQuery.validator.addMethod('decimal', function (value, element) {
    return this.optional(element) || /^((\d+(\\.\d{0,2})?)|((\d*(\.\d{1,2}))))$/.test(value);
}, "Please enter a correct number, format 0.00");

var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };

$(document).ready(function () {

    if ($("#btnCDetails").val() == 'Update')
        $('#CourseId').attr('disabled', true);

    var UploadedFileType;
    var FileExtention;
    var FileSize;
    var ImgData;

    $("#CDImage").change(function (e) {
        if (!e) e = window.event;
        var file = e.target.files[0] || e.srcElement.files[0];
        //var filename = e.target.files[0].name;
        UploadedFileType = file.type;
        FileSize = file.size;

        if (file.type == "image/jpeg") {
            var fileReader = new FileReader();
            fileReader.onload = function (fileLoadedEvent) {
                FileExtention = ".jpg";
                ImgData = fileLoadedEvent.target.result;
            };
            fileReader.readAsDataURL(file);
        }
        else if (file.type == "image/png") {
            var fileReader = new FileReader();
            fileReader.onload = function (fileLoadedEvent) {
                FileExtention = ".png";
                ImgData = fileLoadedEvent.target.result;
            };
            fileReader.readAsDataURL(file);
        }
        else {
            var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
            toastr.error('Upload Images of Extentions .JPG, .JPEG, .PNG', 'Validation Error', opts);
            $("#UploadUserImage").val(null);
        }
    })

    $("#CourseDetailsForm").validate({
        rules: {
            'CourseId': {
                selectNone: true
            },
            'CDCurrency': {
                required: true,
                maxlength: 100
            },
            'CDPrice': {
                required: true,
                maxlength: 20,
                decimal: true
            },
            'CDRating': {
                required: true,
                maxlength: 1,
                numbersonly: true,
            },
            'CDDuration': {
                required: true,
                maxlength: 5,
                numbersonly: true
            },
            'CDNumOfClasses': {
                required: true,
                maxlength: 5,
                numbersonly: true
            },
            'CDImage': {
                required: function () {
                    if ($("#btnCDetails").val() == 'Update')
                        return false;
                    else
                        return true;
                }
            }
        },
        messages: {
            'CourseId': {
                selectNone: 'Please Select Course'
            },
            'CDCurrency': {
                required: 'Enter Currency',
                maxlength: 'Must enter Max of 2 characters'
            },
            'CDPrice': {
                required: 'Enter Price',
                maxlength: 'Must enter Max of 10 digits'
            },
            'CDRating': {
                required: 'Enter Rating',
                maxlength: 'Must enter only 1 digits'
            },
            'CDDuration': {
                required: 'Enter Duration',
                maxlength: 'Must enter Max of 5 digits'
            },
            'CDNumOfClasses': {
                required: 'Enter Num Of Classes',
                maxlength: 'Must enter Max of 5 digits'
            },
            'CDImage': {
                required: 'Upload a Image'
            }
        },
        submitHandler: function () {
            setTimeout(function () {
                $(".loadingImg").show();
                var _postData = {
                    CDetailsId: $('#PKID').val(),
                    CourseId: $('#CourseId').val(),
                    Currency: $('#CDCurrency').val(),
                    Price: $('#CDPrice').val(),
                    Rating: $('#CDRating').val(),
                    Duration: $('#CDDuration').val(),
                    NumOfClasses: $('#CDNumOfClasses').val(),
                    Image: ImgData,
                    ImgType: FileExtention,
                    FileSize: FileSize,
                    btnType: $("#btnCDetails").val()
                };

                $.ajax({
                    type: "POST",
                    url: "/CPanelAdmin/InsertUpdateCourseDetails",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        if (!response.Status)
                            toastr.error(response.Message, response.Caption, opts);
                        else {
                            swal({
                                title: "Success!",
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    ClearFields();
                                    $('.notification-sidebar').removeClass('open');
                                    location.reload();
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        toastr.error(xhr.responseText, '', opts);
                    }
                });
            }, 0);
        }
    });

    $("#btnCancel").click(function () {
        ClearFields();
    });

    $('.notification-sidebar-close').on('click', function () {
        $('.notification-sidebar').removeClass('open');
    });
});

function ClearFields() {
    $("#CourseId").val('0');
    $("#CDCurrency").val('');
    $("#CDPrice").val('');
    $("#CDRating").val('');
    $("#CDDuration").val('');
    $("#CDNumOfClasses").val('');
}