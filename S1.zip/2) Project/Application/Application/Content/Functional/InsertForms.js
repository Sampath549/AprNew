﻿jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

jQuery.validator.addMethod("numbersonly", function (value, element) {
    return this.optional(element) || /^[0-9]+$/i.test(value);
}, "Enter Only Numbers");

jQuery.validator.addMethod("customEmail", function (value, element) {
    return /^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{1,5}|[0-9]{1,3})(\]?)$/.test(value);
}, "Enter a Valid Email");

$(document).ready(function () {
    $('.notification-sidebar-close').on('click', function () {
        $('.notification-sidebar').removeClass('open');
    });

    // Validations & ajax Calls
    $("#ManualForm").validate({
        rules: {
            'FoName': {
                required: true,
                lettersonly: true
            },
            'FoEmail': {
                required: true,
                customEmail: true
            },
            'FoMobile': {
                required: true,
                numbersonly: true
            },
            'FoCourse': {
                required: true
            },
            'FoMessage': {
                required: true
            }
        },
        messages: {
            'FoName': {
                required: 'Enter Name'
            },
            'FoEmail': {
                required: 'Enter Email'
            },
            'FoMobile': {
                required: 'Enter Mobile'
            },
            'FoCourse': {
                required: 'Enter Course'
            },
            'FoMessage': {
                required: 'Enter Message'
            }
        },
        submitHandler: function () {
            setTimeout(function () {
                $(".loadingImg").show();

                var _postData = {
                    Name: $('#FoName').val(),
                    Email: $('#FoEmail').val(),
                    Mobile: $('#FoMobile').val(),
                    Course: $('#FoCourse').val(),
                    Message: $('#FoMessage').val()
                };
               
                $.ajax({
                    type: "POST",
                    url: "/CPanelAdmin/CreateManualForm",
                    data: _postData,
                    dataType: "json",
                    cache: false,
                    headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                    success: function (response) {
                        var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };
                        if (!response.Status)
                            toastr.error(response.Message, response.Caption, opts);
                        else {
                            swal({
                                title: "Success!",
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    ClearFields();
                                    $('.notification-sidebar').removeClass('open');
                                    location.reload();
                                }
                            });
                        }
                        $(".loadingImg").hide();
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        toastr.error(xhr.responseText, '', opts);
                    }
                });
            }, 0);
        }
    });
});

function ClearFields() {
    $("#FoName").val('');
    $("#FoEmail").val('');
    $("#FoMobile").val('');
    $("#FoCourse").val('');
    $("#FoMessage").val('');
}