﻿jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };

$(document).ready(function () {
    $("#StudentDetailsForm").validate({
        rules: {
            SDFName: {
                required: true,
                maxlength: 35,
                lettersonly: true
            },
            SDLName: {
                required: true,
                maxlength: 35,
                lettersonly: true
            }
        },
        messages: {
            SDFName: {
                required: 'Enter First Name',
                maxlength: 'Max 35 Characters'
            },
            SDLName: {
                required: 'Enter Last Name',
                maxlength: 'Max 35 Characters',
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();
            var _postData = {
                UserId: $('#SDUID').val(),
                FirstName: $('#SDFName').val(),
                LastName: $('#SDLName').val(),
                IsActive: $('#SDIsActive').prop('checked')
            }

            $.ajax({
                type: "POST",
                url: "/CPanelAdmin/UpdateStudentDetails",
                data: _postData,
                dataType: "json",
                cache: false,
                headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                success: function (response) {
                    setTimeout(function () {
                        console.log(response)
                        if (!response.Status) {
                            toastr.error(response.Message, response.Caption, opts);
                        }
                        else {
                            swal({
                                title: "Success!",
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    location.reload();
                                }
                            });
                        }
                    }, 0);
                    $(".loadingImg").hide();
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    toastr.error(xhr.responseText, '', opts);
                }
            });
        }
    });

    $('.notification-sidebar-close').on('click', function () {
        $('.notification-sidebar').removeClass('open');
    });
});
