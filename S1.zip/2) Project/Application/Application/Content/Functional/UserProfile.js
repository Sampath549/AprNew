﻿jQuery.validator.addMethod("lettersonly", function (value, element) {
    return this.optional(element) || /^[a-z\s]+$/i.test(value);
}, "Enter Only Alphabets");

var opts = { "closeButton": true, "debug": false, "positionClass": "toast-top-full-width", "onclick": null, "showDuration": null, "hideDuration": null, "timeOut": null, "extendedTimeOut": null, "showEasing": "swing", "hideEasing": "linear", "showMethod": "fadeIn", "hideMethod": "fadeOut" };

$(document).ready(function () {
    $("#UserProfileForm").validate({
        rules: {
            UPFName: {
                required: true,
                maxlength: 35,
                lettersonly: true
            },
            UPLName: {
                required: true,
                maxlength: 35,
                lettersonly: true
            },
            UPZipCode: {
                maxlength: 10,
                number: true
            }
        },
        messages: {
            UPFName: {
                required: 'Enter First Name',
                maxlength: 'Max 35 Characters'
            },
            UPLName: {
                required: 'Enter Last Name',
                maxlength: 'Max 35 Characters',
            },
            UPZipCode: {
                minlength: 'Max 10 Digits',
                number: 'Enter Only Numbers'
            }
        },
        submitHandler: function () {
            $(".loadingImg").show();
            var _postData = {
                FirstName: $('#UPFName').val(),
                LastName: $('#UPLName').val(),
                Email: $('#UPEmail').val(),
                Gender: $('#Gender option:selected').val(),
                Address: $('#Address').val(),
                City: $('#UPCity').val(),
                StateId: $('#StateId option:selected').val(),
                CountryId: $('#CountryId option:selected').val(),
                ZipCode: $('#UPZipCode').val()
            }

            $.ajax({
                type: "POST",
                url: "/CPanel/UserProfile",
                data: _postData,
                dataType: "json",
                cache: false,
                headers: { '__RequestVerificationToken': $('input[name=__RequestVerificationToken]').val() },
                success: function (response) {
                    setTimeout(function () {
                        $(".loadingImg").hide();
                        if (!response.Status) {
                            toastr.error(response.Message, response.Caption, opts);
                        }
                        else {
                            swal({
                                title: "Success!",
                                text: response.Message,
                                type: "success",
                                confirmButtonText: "OK"
                            },
                            function (isConfirm) {
                                if (isConfirm) {
                                    window.location.href = response.Data.RedirectUrl;
                                }
                            });
                        }
                    }, 0);
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    toastr.error(xhr.responseText, '', opts);
                }
            });
        }
    });
});