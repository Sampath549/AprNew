﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;

namespace Application.Helper
{
    public class ExceptionLogging
    {
        private static String ErrorlineNo, Errormsg, extype, exurl, ErrorLocation;
        public static void SendErrorToText(Exception ex)
        {
            var _BreakLine = Environment.NewLine;
            string[] GetLine = ex.StackTrace.Split(new string[] { ":line " }, StringSplitOptions.None);
            ErrorlineNo = GetLine[1];
            Errormsg = ex.GetType().Name.ToString();
            extype = ex.GetType().ToString();
            exurl = System.Web.HttpContext.Current.Request.Url.ToString();
            ErrorLocation = ex.Message.ToString();

            try
            {
                string filepath = System.Web.HttpContext.Current.Server.MapPath("~/ErrorLog/");  //Text File Path
                if (!Directory.Exists(filepath))
                    Directory.CreateDirectory(filepath);

                filepath = filepath + DateTime.Today.ToString("dd-MM-yy") + ".txt";   //Text File Name
                if (!File.Exists(filepath))
                    File.Create(filepath).Dispose();

                using (StreamWriter sw = File.AppendText(filepath))
                {
                    string _ErrorDetails = "Error Date & Time:" + " " + DateTime.Now.ToString() + _BreakLine;
                    _ErrorDetails = _ErrorDetails + "Error Line No:" + " " + ErrorlineNo + _BreakLine;
                    _ErrorDetails = _ErrorDetails + "Error Message:" + " " + Errormsg + _BreakLine;
                    _ErrorDetails = _ErrorDetails + "Exception Type:" + " " + extype + _BreakLine;
                    _ErrorDetails = _ErrorDetails + "Error Location:" + " " + ErrorLocation + _BreakLine;
                    _ErrorDetails = _ErrorDetails + "Error Page Url:" + " " + exurl;

                    sw.WriteLine("-----------------------------------------------------------------");
                    sw.WriteLine(_ErrorDetails);
                    sw.WriteLine("------------------------------/End/------------------------------");
                    sw.WriteLine(_BreakLine);
                    sw.Flush();
                    sw.Close();
                }
            }
            catch (Exception e)
            {
                e.ToString();
            }
        }
    }
}