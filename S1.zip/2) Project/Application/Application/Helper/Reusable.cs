﻿using Application.App_Start;
using Application.Models.SharedEntities;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;

namespace Application.Helper
{
    public static class Reusable
    {
        public static string RedirectPage(string RoleCode)
        {
            try
            {
                if (RoleCode == "DEV")
                    return "/CPanelDev/Dashboard";
                else if (RoleCode == "STU")
                    return "/CPanelStudent/Dashboard";
                else if (RoleCode == "ADM")
                    return "/CPanelAdmin/Dashboard";
                else if (RoleCode == "SADM")
                    return "";
                else
                    return "";
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static void ErrorMsgText(Exception ex)
        {
            if (Convert.ToBoolean(GlobalVariables.Shared.InsertErrorLog))
                ExceptionLogging.SendErrorToText(ex);
        }
        public static string BindMenus()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                if (SessionHandler.Menus == null || SessionHandler.Menus == "")
                {
                    //API Call		
                    ArrayList _Array = new ArrayList();
                    _Array.Add(RSAPattern.Encrypt(_SessionUserDetails.RoleCode));
                    string _Menu = ApiHelper.PostData_Json("api/CPanel/BindMenus?Values=", _Array);
                    Result<string> _Result = JsonConvert.DeserializeObject<Result<string>>(_Menu);

                    SessionHandler.Menus = _Result.Data;
                }
                return SessionHandler.Menus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> GenderList()
        {
            try
            {
                List<SelectListItem> GenderList = new List<SelectListItem>();
                GenderList.Add(new SelectListItem { Text = "Select Gender", Value = "0" });
                GenderList.Add(new SelectListItem { Text = "Male", Value = "1" });
                GenderList.Add(new SelectListItem { Text = "Female", Value = "2" });
                GenderList.Add(new SelectListItem { Text = "Other", Value = "3" });
                return GenderList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<SelectListItem> CountriesList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> CountriesList = new List<SelectListItem>();
                if (SessionHandler.Countries == null)
                {
                    //API Call
                    ArrayList _Array = new ArrayList();
                    string _Countries = ApiHelper.PostData_Json("api/CPanel/GetCountries?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultCountries = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Countries);

                    CountriesList.Add(new SelectListItem { Text = "Select Country", Value = "0" });
                    for (int k = 0; k < _ResultCountries.Data.Count; k++)
                    {
                        CountriesList.Add(new SelectListItem
                        {
                            Text = _ResultCountries.Data[k].Description.ToString(),
                            Value = _ResultCountries.Data[k].Id.ToString()
                        });
                    }
                    SessionHandler.Countries = CountriesList;
                }
                return SessionHandler.Countries;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> StatesList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> StatesList = new List<SelectListItem>();
                if (SessionHandler.States == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _States = ApiHelper.PostData_Json("api/CPanel/GetStates?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultStates = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_States);

                    StatesList.Add(new SelectListItem { Text = "Select State", Value = "0" });
                    for (int i = 0; i < _ResultStates.Data.Count; i++)
                    {
                        StatesList.Add(new SelectListItem
                        {
                            Text = _ResultStates.Data[i].Description.ToString(),
                            Value = _ResultStates.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.States = StatesList;
                }
                return SessionHandler.States;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> RolesList()
        {
            SE_Users _SessionUserDetails = SessionHandler.UserDetails as SE_Users;
            try
            {
                List<SelectListItem> _lst = new List<SelectListItem>();
                if (SessionHandler.Roles == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _Roles = ApiHelper.PostData_Json("api/CPanel/RolesList?Values=", _Array);
                    Result<List<SE_RefValues>> _ResultRoles = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Roles);

                    _lst.Add(new SelectListItem { Text = "Select Role", Value = "0" });
                    for (int i = 0; i < _ResultRoles.Data.Count; i++)
                    {
                        _lst.Add(new SelectListItem
                        {
                            Text = _ResultRoles.Data[i].Description.ToString(),
                            Value = _ResultRoles.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.Roles = _lst;
                }
                return SessionHandler.Roles;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<SelectListItem> CourseCategoryList()
        {
            try
            {
                List<SelectListItem> _lst = new List<SelectListItem>();

                ArrayList _Array = new ArrayList();
                string _CCateogry = ApiHelper.PostData_Json("api/CPanelAdmin/CourseCategoryList?Values=", _Array);
                Result<List<SE_RefValues>> _Result = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_CCateogry);

                _lst.Add(new SelectListItem { Text = "Select Course Cateogry", Value = "0" });
                for (int i = 0; i < _Result.Data.Count; i++)
                {
                    _lst.Add(new SelectListItem
                    {
                        Text = _Result.Data[i].Description.ToString(),
                        Value = _Result.Data[i].Id.ToString()
                    });
                }
                return _lst;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }




        public static List<string> ProfilePicExtentions()
        {
            try
            {
                List<string> _ext = new List<string>();
                _ext.Add(".JPG");
                _ext.Add(".JPEG");
                _ext.Add(".PNG");
                _ext.Add(".jpg");
                _ext.Add(".jpge");
                _ext.Add(".png");
                return _ext;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> CourseList()
        {
            try
            {
                List<SelectListItem> _lst = new List<SelectListItem>();
                if (SessionHandler.SessionCourseList == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _CCateogry = ApiHelper.PostData_Json("api/CPanelAdmin/CourseList?Values=", _Array);
                    Result<List<SE_RefValues>> _Result = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_CCateogry);

                    _lst.Add(new SelectListItem { Text = "Select Course", Value = "0" });
                    for (int i = 0; i < _Result.Data.Count; i++)
                    {
                        _lst.Add(new SelectListItem
                        {
                            Text = _Result.Data[i].Description.ToString(),
                            Value = _Result.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.SessionCourseList = _lst;
                }
                return SessionHandler.SessionCourseList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<SelectListItem> StudentsList()
        {
            try
            {
                List<SelectListItem> _lst = new List<SelectListItem>();
                if (SessionHandler.SessionStudentsList == null)
                {
                    ArrayList _Array = new ArrayList();
                    string _Studentslst = ApiHelper.PostData_Json("api/CPanelAdmin/StudentsList?Values=", _Array);
                    Result<List<SE_RefValues>> _Result = JsonConvert.DeserializeObject<Result<List<SE_RefValues>>>(_Studentslst);

                    for (int i = 0; i < _Result.Data.Count; i++)
                    {
                        _lst.Add(new SelectListItem
                        {
                            Text = _Result.Data[i].Description.ToString(),
                            Value = _Result.Data[i].Id.ToString()
                        });
                    }
                    SessionHandler.SessionStudentsList = _lst;
                }
                return SessionHandler.SessionStudentsList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}