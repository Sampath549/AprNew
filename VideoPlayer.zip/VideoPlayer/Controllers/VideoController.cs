﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using VideoPlayer.Models;

namespace VideoPlayer.Controllers
{
    public class VideoController : Controller
    {
        public ActionResult List()
        {
            var fileContents = System.IO.File.ReadAllText(Server.MapPath(@"~/ListContent.txt"));

            IList<VideoList> _List = new List<VideoList>();
            int k = 1;
            foreach (string name in fileContents.Split('\n'))
            {
                if (!string.IsNullOrEmpty(name))
                {
                    _List.Add(new VideoList
                    {
                        Id = Convert.ToInt32(k),
                        VideoName = name.Split('\r')[0],
                    });
                    k++;
                }
            }
            //IList<VideoList> _List2 = new List<VideoList>() { 
            //        new VideoList(){ Id=1, VideoName="CSRF-Method-1" },
            //        new VideoList(){ Id=2, VideoName="XSS-Method-1"}
            //    };
            return View(_List);
        }

        public ActionResult Play(VideoList _lst)
        {
            ViewBag.VideoName = _lst.VideoName;
            ViewBag.VideoPath = "/Videos/" + _lst.VideoName + ".mp4";
            return View();
        }
    }
}