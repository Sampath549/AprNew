﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace VideoPlayer.Models
{
    public class VideoList
    {
        public int Id { get; set; }

        [Display(Name = "Name")]
        public string VideoName { get; set; }
    }
}