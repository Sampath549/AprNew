﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(VideoPlayer.Startup))]
namespace VideoPlayer
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
